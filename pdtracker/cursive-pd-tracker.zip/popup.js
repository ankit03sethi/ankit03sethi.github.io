// Cursive PD Tracker — popup UI
const SUPABASE_URL = "https://bttppihskbfmxwujyztj.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ0dHBwaWhza2JmbXh3dWp5enRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk2OTk2OTksImV4cCI6MjA5NTI3NTY5OX0.HVy2iOv9t4u6vA2TaMolp2GOrvi-5m9pLW1lXKCnEl8";

const $ = (s) => document.querySelector(s);
const show = (el) => el && el.classList.remove("hidden");
const hide = (el) => el && el.classList.add("hidden");

async function init() {
  const { pd_jwt, pd_email, pd_running, pd_last_fetch, pd_last_ok, pd_pending_count } = await chrome.storage.local.get([
    "pd_jwt", "pd_email", "pd_running", "pd_last_fetch", "pd_last_ok", "pd_pending_count"
  ]);

  if (pd_jwt && pd_email) {
    hide($("#loginView"));
    show($("#signedView"));
    $("#emailDisplay").textContent = pd_email;
    $("#lastFetch").textContent = pd_last_fetch ? new Date(pd_last_fetch).toLocaleString() : "Not yet";
    $("#lastOk").textContent = pd_last_ok ? new Date(pd_last_ok).toLocaleString() : "Not yet";
    $("#pendingCount").textContent = (pd_pending_count ?? "—") + "";

    if (pd_running === false) {
      $("#statusPill").className = "status-pill off";
      $("#statusText").textContent = "Tracker stopped";
      hide($("#stopBtn")); show($("#startBtn"));
    } else {
      $("#statusPill").className = "status-pill on";
      $("#statusText").textContent = "Tracker running";
    }
  } else {
    show($("#loginView"));
    hide($("#signedView"));
  }
}

$("#loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = $("#loginErr");
  hide(err);
  const btn = $("#loginBtn");
  btn.disabled = true; btn.textContent = "Signing in...";
  try {
    const email = $("#email").value.trim().toLowerCase();
    const password = $("#password").value;
    const resp = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "apikey": SUPABASE_ANON_KEY },
      body: JSON.stringify({ email, password }),
    });
    const j = await resp.json();
    if (!resp.ok) throw new Error(j.error_description || j.message || "Login failed");
    if (!j.access_token) throw new Error("No token returned");

    await chrome.storage.local.set({
      pd_jwt: j.access_token,
      pd_refresh_token: j.refresh_token,
      pd_jwt_expires_at: Date.now() + (j.expires_in * 1000),
      pd_email: email,
      pd_running: true,
    });
    // Notify background to start
    chrome.runtime.sendMessage({ action: "pd_signed_in" });
    init();
  } catch (e2) {
    err.textContent = e2.message;
    show(err);
  } finally {
    btn.disabled = false; btn.textContent = "Sign in";
  }
});

$("#signOutBtn").addEventListener("click", async () => {
  await chrome.storage.local.set({ pd_running: false });
  await chrome.storage.local.remove(["pd_jwt", "pd_refresh_token", "pd_jwt_expires_at", "pd_email", "pd_last_fetch", "pd_last_ok"]);
  chrome.runtime.sendMessage({ action: "pd_signed_out" });
  init();
});

$("#stopBtn").addEventListener("click", async () => {
  await chrome.storage.local.set({ pd_running: false });
  chrome.runtime.sendMessage({ action: "pd_stop" });
  init();
});

$("#startBtn").addEventListener("click", async () => {
  await chrome.storage.local.set({ pd_running: true });
  chrome.runtime.sendMessage({ action: "pd_start" });
  init();
});

$("#dashBtn").addEventListener("click", () => {
  chrome.tabs.create({ url: "https://cursive.world/pdtracker/" });
});

init();
