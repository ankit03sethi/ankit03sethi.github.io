// Cursive PD Tracker — service worker
// Replaces the old Apps Script driven background. All endpoints are Supabase Edge Functions.
//
// Loop: chrome.alarms every 3 sec.
//   1. If not signed in OR pd_running===false: skip.
//   2. Otherwise: refresh recipes if >24h old, refresh JWT if near expiry,
//      send heartbeat if >5 min, then fetch & process a batch of products.

const SUPABASE_URL = "https://bttppihskbfmxwujyztj.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ0dHBwaWhza2JmbXh3dWp5enRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk2OTk2OTksImV4cCI6MjA5NTI3NTY5OX0.HVy2iOv9t4u6vA2TaMolp2GOrvi-5m9pLW1lXKCnEl8";
const EXTENSION_VERSION = "1.0.0";

const ALARM = "pd_tick";
const TICK_SECONDS = 3;
const BATCH_SIZE = 15;
const PARALLEL_TABS = 3;
const TAB_TIMEOUT_MS = 25000;
const HEARTBEAT_INTERVAL_MS = 5 * 60 * 1000;
const RECIPES_TTL_MS = 24 * 60 * 60 * 1000;

// ---------- Lifecycle ----------
chrome.runtime.onInstalled.addListener(setupAlarm);
chrome.runtime.onStartup.addListener(setupAlarm);

function setupAlarm() {
  chrome.alarms.create(ALARM, { periodInMinutes: TICK_SECONDS / 60 });
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ALARM) tick().catch(e => console.warn("[PD] tick err:", e));
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "pd_signed_in" || msg.action === "pd_start") {
    setupAlarm(); tick();
  }
  if (msg.action === "pd_stop" || msg.action === "pd_signed_out") {
    chrome.alarms.clear(ALARM);
  }
  sendResponse({ ok: true });
  return true;
});

// ---------- Auth helpers ----------
async function getAuth() {
  const s = await chrome.storage.local.get(["pd_jwt", "pd_refresh_token", "pd_jwt_expires_at", "pd_running"]);
  if (s.pd_running === false) return null;
  if (!s.pd_jwt) return null;
  // Refresh if expiring within 5 min
  if (s.pd_jwt_expires_at && (s.pd_jwt_expires_at - Date.now()) < 5 * 60 * 1000) {
    if (s.pd_refresh_token) {
      try {
        const r = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "apikey": SUPABASE_ANON_KEY },
          body: JSON.stringify({ refresh_token: s.pd_refresh_token }),
        });
        const j = await r.json();
        if (r.ok && j.access_token) {
          await chrome.storage.local.set({
            pd_jwt: j.access_token,
            pd_refresh_token: j.refresh_token,
            pd_jwt_expires_at: Date.now() + (j.expires_in * 1000),
          });
          return j.access_token;
        }
      } catch (e) { console.warn("[PD] refresh failed:", e); }
    }
  }
  return s.pd_jwt;
}

async function apiFetch(path, opts = {}) {
  const jwt = await getAuth();
  if (!jwt) throw new Error("Not signed in");
  return fetch(`${SUPABASE_URL}${path}`, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${jwt}`,
      "apikey": SUPABASE_ANON_KEY,
      ...(opts.headers || {}),
    },
  });
}

// ---------- Recipes (server-driven scrape configs) ----------
async function refreshRecipesIfStale() {
  const s = await chrome.storage.local.get(["pd_recipes", "pd_recipes_at"]);
  if (s.pd_recipes && s.pd_recipes_at && (Date.now() - s.pd_recipes_at) < RECIPES_TTL_MS) return s.pd_recipes;
  try {
    const r = await fetch(`${SUPABASE_URL}/functions/v1/analytics-recipes`, {
      headers: { "apikey": SUPABASE_ANON_KEY },
    });
    const j = await r.json();
    if (j.ok && j.recipes) {
      await chrome.storage.local.set({ pd_recipes: j.recipes, pd_recipes_at: Date.now() });
      return j.recipes;
    }
  } catch (e) { console.warn("[PD] recipes refresh:", e); }
  return s.pd_recipes || null;
}

// ---------- Heartbeat ----------
async function sendHeartbeatIfDue() {
  const s = await chrome.storage.local.get(["pd_last_heartbeat", "pd_pending_count"]);
  if (s.pd_last_heartbeat && (Date.now() - s.pd_last_heartbeat) < HEARTBEAT_INTERVAL_MS) return;
  try {
    const r = await apiFetch("/functions/v1/analytics-heartbeat", {
      method: "POST",
      body: JSON.stringify({
        extension_version: EXTENSION_VERSION,
        platform_os: navigator.platform || "Unknown",
        active_products: s.pd_pending_count || 0,
      }),
    });
    if (r.ok) await chrome.storage.local.set({ pd_last_heartbeat: Date.now() });
  } catch (e) { console.warn("[PD] heartbeat:", e); }
}

// ---------- Core tick ----------
let _tickInProgress = false;
async function tick() {
  if (_tickInProgress) return;
  const jwt = await getAuth();
  if (!jwt) return;
  _tickInProgress = true;
  try {
    await refreshRecipesIfStale();
    await sendHeartbeatIfDue();

    // Fetch next batch
    const r = await apiFetch(`/functions/v1/analytics-next-products?limit=${BATCH_SIZE}`);
    if (!r.ok) {
      console.warn("[PD] next-products failed:", r.status);
      return;
    }
    const j = await r.json();
    const products = j.products || [];
    await chrome.storage.local.set({ pd_pending_count: products.length });
    if (products.length === 0) return;

    await chrome.storage.local.set({ pd_last_fetch: Date.now() });

    // Process in parallel chunks of PARALLEL_TABS
    const results = [];
    for (let i = 0; i < products.length; i += PARALLEL_TABS) {
      const chunk = products.slice(i, i + PARALLEL_TABS);
      const chunkResults = await Promise.all(chunk.map(p => extractViaTab(p)));
      results.push(...chunkResults);
    }

    // Post snapshots
    if (results.length > 0) {
      const validResults = results.filter(r => r != null);
      if (validResults.length > 0) {
        const postR = await apiFetch("/functions/v1/analytics-snapshot", {
          method: "POST",
          body: JSON.stringify({ results: validResults }),
        });
        if (postR.ok) {
          await chrome.storage.local.set({ pd_last_ok: Date.now() });
        }
      }
    }
  } finally {
    _tickInProgress = false;
  }
}

// ---------- Tab-based extraction ----------
async function extractViaTab(product) {
  try {
    const tab = await chrome.tabs.create({ url: product.product_url, active: false });
    await waitForTabComplete(tab.id, 8000);
    const recipes = (await chrome.storage.local.get("pd_recipes")).pd_recipes || {};
    const recipe = recipes[product.platform] || {};
    // Ask the content script
    const data = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), TAB_TIMEOUT_MS);
      chrome.tabs.sendMessage(tab.id, { action: "extractRating", recipe }, (response) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response);
      });
    });
    chrome.tabs.remove(tab.id).catch(() => {});
    if (!data || !data.success) {
      return { product_id_fk: product.id, status: "fail_temporary" };
    }
    return {
      product_id_fk: product.id,
      rating: data.rating ?? null,
      review_count: data.reviewCount ?? null,
      price: data.price ?? null,
      seller: data.seller ?? null,
      status: (data.price != null || data.rating != null) ? "ok" : "fail_temporary",
    };
  } catch (e) {
    console.warn("[PD] extract failed for", product.product_url, e);
    return { product_id_fk: product.id, status: "fail_temporary" };
  }
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(false);
    }, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        // Brief settle delay
        setTimeout(() => resolve(true), 1500);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// Kick the loop on load (if user is already signed in)
setupAlarm();
tick().catch(() => {});
