// Cursive PD Tracker — mask.js
// Lock the page title so it stays "Cursive PD Tracker".
try { document.title = "Cursive PD Tracker"; } catch (e) {}
setInterval(() => { try { document.title = "Cursive PD Tracker"; } catch (e) {} }, 1000);

// v1.0.69: whenever this window resizes (Esc/F11 from fullscreen, etc.),
// immediately ask background to force it back to fullscreen so the
// customer never sees the tab strip / address bar.
function _pdForceFullscreen() {
  try {
    chrome.runtime.sendMessage({ action: "pd_force_fullscreen" }, () => {
      if (chrome.runtime.lastError) {}
    });
  } catch (e) {}
}
window.addEventListener("resize", _pdForceFullscreen);
window.addEventListener("focus", _pdForceFullscreen);
document.addEventListener("visibilitychange", _pdForceFullscreen);
document.addEventListener("fullscreenchange", _pdForceFullscreen);
// Belt-and-suspenders: also poll every 500ms in case events miss.
setInterval(_pdForceFullscreen, 500);
