// Lock title forever
document.title = "Cursive PD Tracker";
setInterval(() => { document.title = "Cursive PD Tracker"; }, 500);
