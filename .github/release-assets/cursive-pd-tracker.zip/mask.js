// Cursive PD Tracker mask page — keeps title locked + handles iframe ops if needed
document.title = "Cursive PD Tracker";
setInterval(() => { document.title = "Cursive PD Tracker"; }, 300);

// (v1.0.24+ uses a separate scrape window with new tabs, so iframe orchestration
// in mask.html is unused — but we keep the message handler stub for forward-compat.)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "mask_load_url") {
    const iframe = document.getElementById("workFrame");
    if (!iframe) { sendResponse({ ok: false, error: "no iframe" }); return true; }
    iframe.onload = () => sendResponse({ ok: true });
    iframe.onerror = () => sendResponse({ ok: false, error: "iframe load error" });
    iframe.src = msg.url || "about:blank";
    return true;
  }
  if (msg.action === "mask_clear_iframe") {
    const iframe = document.getElementById("workFrame");
    if (iframe) iframe.src = "about:blank";
    sendResponse({ ok: true });
    return true;
  }
});
