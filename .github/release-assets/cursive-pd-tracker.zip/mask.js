// Cursive PD Tracker — mask.js
try { document.title = "Cursive PD Tracker"; } catch (e) {}
setInterval(() => { try { document.title = "Cursive PD Tracker"; } catch (e) {} }, 1000);

// v1.0.72: X button click → minimize the window
function _pdMinimize() {
  try {
    chrome.runtime.sendMessage({ action: "pd_minimize_hero" }, () => {
      if (chrome.runtime.lastError) {}
    });
  } catch (e) {}
}
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("pdMinBtn");
  if (btn) btn.addEventListener("click", _pdMinimize);
});

// v1.0.69: always-fullscreen polling
function _pdForceFullscreen() {
  try {
    chrome.runtime.sendMessage({ action: "pd_force_fullscreen" }, () => {
      if (chrome.runtime.lastError) {}
    });
  } catch (e) {}
}
window.addEventListener("resize", _pdForceFullscreen);
window.addEventListener("focus", _pdForceFullscreen);
document.addEventListener("visibilitychange", _pdForceFullscreen);
document.addEventListener("fullscreenchange", _pdForceFullscreen);
setInterval(_pdForceFullscreen, 500);
