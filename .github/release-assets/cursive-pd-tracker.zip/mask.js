// Cursive PD Tracker — mask.js
// Locks the page title so it stays "Cursive PD Tracker" even if some other
// script tries to overwrite it.
try { document.title = "Cursive PD Tracker"; } catch (e) {}
setInterval(() => { try { document.title = "Cursive PD Tracker"; } catch (e) {} }, 1000);
