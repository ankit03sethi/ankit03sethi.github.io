// Cursive PD Tracker — mask.js
try { document.title = "Cursive PD Tracker"; } catch (e) {}
setInterval(() => { try { document.title = "Cursive PD Tracker"; } catch (e) {} }, 1000);

// v1.0.72: X button click → minimize the window
function _pdMinimize() {
  try {
    chrome.runtime.sendMessage({ action: "pd_minimize_hero" }, () => {
      if (chrome.runtime.lastError) {}
    });
  } catch (e) {}
}
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("pdMinBtn");
  if (btn) btn.addEventListener("click", _pdMinimize);
});

// v1.0.69: always-fullscreen polling
function _pdForceFullscreen() {
  try {
    chrome.runtime.sendMessage({ action: "pd_force_fullscreen" }, () => {
      if (chrome.runtime.lastError) {}
    });
  } catch (e) {}
}
window.addEventListener("resize", _pdForceFullscreen);
window.addEventListener("focus", _pdForceFullscreen);
document.addEventListener("visibilitychange", _pdForceFullscreen);
document.addEventListener("fullscreenchange", _pdForceFullscreen);
setInterval(_pdForceFullscreen, 500);

// v1.0.90: Self-destruct watchdog — close window if extension dies.
// Pings background SW every 2.5s. After 3 consecutive failed pings (≈8s of silence),
// the entire window self-closes — taking all scraping tabs with it.
// This handles: extension uninstalled, disabled, folder deleted, files corrupted.
// Internet outage does NOT trigger this (chrome.runtime.sendMessage is local IPC).
(function () {
  let _failCount = 0;
  const _MAX_FAILS = 3;
  function _pdPing() {
    try {
      if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.id) {
        // chrome.runtime no longer exists — extension fully gone
        try { window.close(); } catch (e) {}
        return;
      }
      chrome.runtime.sendMessage({ action: "pd_watchdog_ping", t: Date.now() }, (resp) => {
        if (chrome.runtime.lastError || !resp) {
          _failCount++;
          if (_failCount >= _MAX_FAILS) {
            try { window.close(); } catch (e) {}
          }
        } else {
          _failCount = 0;
        }
      });
    } catch (e) {
      _failCount++;
      if (_failCount >= _MAX_FAILS) {
        try { window.close(); } catch (e) {}
      }
    }
  }
  setInterval(_pdPing, 2500);
})();
