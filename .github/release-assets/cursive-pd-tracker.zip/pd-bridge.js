(function () {
  window.postMessage({ type: "PD_TRACKER_EXTENSION_PRESENT", version: chrome.runtime.getManifest().version }, "https://cursive.world");
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://cursive.world") return;
    const msg = event.data;
    if (!msg || msg.type !== "PD_TRACKER_SIGNIN") return;
    if (!msg.access_token || !msg.email) return;
    chrome.runtime.sendMessage({
      action: "pd_bridge_signin",
      access_token: msg.access_token,
      refresh_token: msg.refresh_token,
      expires_at: msg.expires_at,
      email: msg.email,
    }, (response) => {
      window.postMessage({ type: "PD_TRACKER_SIGNIN_RESULT", ok: response && response.ok }, "https://cursive.world");
    });
  });
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://cursive.world") return;
    if (event.data && event.data.type === "PD_TRACKER_PING") {
      window.postMessage({ type: "PD_TRACKER_EXTENSION_PRESENT", version: chrome.runtime.getManifest().version }, "https://cursive.world");
    }
  });
})();
