// pd-bridge.js - injected on cursive.world/pdtracker/*
// Tells the page "extension is installed" and accepts auto-pairing JWT from page.
// SECURITY: only accepts messages from the same origin (cursive.world).

(function () {
  // 1) Announce extension is present so the page can show "Connected"
  window.postMessage({ type: "PD_TRACKER_EXTENSION_PRESENT", version: chrome.runtime.getManifest().version }, "https://cursive.world");

  // 2) Listen for the dashboard sending us a JWT to sign in with
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://cursive.world") return;
    const msg = event.data;
    if (!msg || msg.type !== "PD_TRACKER_SIGNIN") return;
    if (!msg.access_token || !msg.email) return;

    chrome.runtime.sendMessage({
      action: "pd_bridge_signin",
      access_token: msg.access_token,
      refresh_token: msg.refresh_token,
      expires_at: msg.expires_at,
      email: msg.email,
    }, (response) => {
      // Tell the page result
      window.postMessage({
        type: "PD_TRACKER_SIGNIN_RESULT",
        ok: response && response.ok,
      }, "https://cursive.world");
    });
  });

  // 3) Respond to ping from page (so it can check if extension is installed at any time)
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://cursive.world") return;
    if (event.data && event.data.type === "PD_TRACKER_PING") {
      window.postMessage({ type: "PD_TRACKER_EXTENSION_PRESENT", version: chrome.runtime.getManifest().version }, "https://cursive.world");
    }
  });
})();
