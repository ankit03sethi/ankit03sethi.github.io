// Cursive PD Tracker — offscreen background scraper v1.0.10
// Runs in a hidden offscreen document. Does fetch + DOMParser + extraction.
// No tabs, no windows, no visible activity at all.

console.log('[PD-OFFSCREEN] loaded v1.0.10');

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== 'pd_scrape_url') return;
  scrapeUrl(msg.product).then(sendResponse).catch(e => {
    console.warn('[PD-OFFSCREEN] err', e);
    sendResponse({ success: false, error: e.message });
  });
  return true;
});

async function scrapeUrl(product) {
  try {
    const res = await fetch(product.product_url, {
      credentials: 'include',
      headers: { 'Accept': 'text/html,*/*' },
      redirect: 'follow',
    });
    if (!res.ok) return { success: false, status: 'fail_temporary', reason: 'http_' + res.status };
    const html = await res.text();
    if (html.length < 500) return { success: false, status: 'fail_temporary', reason: 'empty_body' };

    const doc = new DOMParser().parseFromString(html, 'text/html');
    const data = extract(doc, html, product.platform);
    return {
      success: !!(data.price || data.rating),
      rating: data.rating, review_count: data.reviewCount,
      price: data.price, seller: data.seller,
    };
  } catch (e) {
    return { success: false, status: 'fail_temporary', reason: e.message };
  }
}

function extract(doc, html, platform) {
  let rating = null, reviewCount = null, price = null, seller = null;

  // ===== JSON-LD: works for Amazon, Flipkart, FirstCry =====
  try {
    const scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    for (const s of scripts) {
      try {
        const j = JSON.parse(s.textContent);
        const items = Array.isArray(j) ? j : [j];
        for (const item of items) {
          if (item.aggregateRating) {
            if (item.aggregateRating.ratingValue && !rating) {
              const v = parseFloat(item.aggregateRating.ratingValue);
              if (v >= 1 && v <= 5) rating = v;
            }
            const rc = item.aggregateRating.ratingCount || item.aggregateRating.reviewCount;
            if (rc && !reviewCount) reviewCount = parseInt(String(rc).replace(/,/g, ''));
          }
          if (item.offers && !price) {
            const offers = Array.isArray(item.offers) ? item.offers[0] : item.offers;
            if (offers.price) {
              const p = parseFloat(String(offers.price).replace(/,/g, ''));
              if (p >= 10) price = String(Math.round(p));
            }
          }
          if (item.brand && !seller) {
            seller = typeof item.brand === 'string' ? item.brand : item.brand.name;
          }
        }
      } catch {}
    }
  } catch {}

  // ===== Meesho: __NEXT_DATA__ JSON =====
  if (platform === 'Meesho' && (!price || !rating)) {
    try {
      const nd = doc.querySelector('#__NEXT_DATA__');
      if (nd) {
        const j = JSON.parse(nd.textContent);
        const single = j?.props?.pageProps?.initialState?.productDetails?.singleProductDetails;
        if (single) {
          if (single.transient_price && !price) price = String(Math.round(single.transient_price));
          if (single.price && !price) price = String(Math.round(single.price));
          if (single.product_rating?.avg_rating && !rating) rating = parseFloat(single.product_rating.avg_rating);
          if (single.product_rating?.rating_count && !reviewCount) reviewCount = single.product_rating.rating_count;
          if (single.supplier_name && !seller) seller = single.supplier_name;
          if (single.shop_name && !seller) seller = single.shop_name;
        }
      }
    } catch {}
  }

  // ===== Myntra: window.__myx in script tag =====
  if (platform === 'Myntra' && (!price || !rating)) {
    try {
      const m = html.match(/window\.__myx\s*=\s*({[\s\S]*?});\s*<\/script>/);
      if (m) {
        const j = JSON.parse(m[1]);
        const pd = j?.pdpData;
        if (pd) {
          if (pd.price?.discounted && !price) price = String(Math.round(pd.price.discounted));
          if (pd.price?.mrp && !price) price = String(Math.round(pd.price.mrp));
          if (pd.ratings?.averageRating && !rating) rating = parseFloat(pd.ratings.averageRating);
          if (pd.ratings?.totalCount && !reviewCount) reviewCount = pd.ratings.totalCount;
          if (pd.brand?.name && !seller) seller = pd.brand.name;
        }
      }
    } catch {}
  }

  // ===== Generic regex fallback (price from HTML) =====
  if (!price) {
    const patterns = [
      /"price"\s*:\s*"?([\d,]+\.?\d*)"?/,
      /"sellingPrice"\s*:\s*"?([\d,]+\.?\d*)"?/,
      /"discountedPrice"\s*:\s*"?([\d,]+\.?\d*)"?/,
      /"finalPrice"\s*:\s*"?([\d,]+\.?\d*)"?/,
      /"offerPrice"\s*:\s*"?([\d,]+\.?\d*)"?/,
    ];
    for (const re of patterns) {
      const m = html.match(re);
      if (m) {
        const v = parseFloat(m[1].replace(/,/g, ''));
        if (v >= 10 && v < 1000000) { price = String(Math.round(v)); break; }
      }
    }
  }

  // ===== Generic regex fallback (rating from HTML) =====
  if (!rating) {
    const ratingPatterns = [
      /"ratingValue"\s*:\s*"?(\d+\.?\d*)"?/,
      /"averageRating"\s*:\s*"?(\d+\.?\d*)"?/,
      /"avgRating"\s*:\s*"?(\d+\.?\d*)"?/,
    ];
    for (const re of ratingPatterns) {
      const m = html.match(re);
      if (m) {
        const v = parseFloat(m[1]);
        if (v >= 1 && v <= 5) { rating = v; break; }
      }
    }
  }

  // ===== Generic regex fallback (review count) =====
  if (!reviewCount) {
    const m = html.match(/"reviewCount"\s*:\s*"?(\d+)"?/) ||
              html.match(/"ratingCount"\s*:\s*"?(\d+)"?/);
    if (m) reviewCount = parseInt(m[1]);
  }

  return { rating, reviewCount, price, seller };
}
