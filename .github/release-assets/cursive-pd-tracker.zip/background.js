const SUPABASE_URL = "https://bttppihskbfmxwujyztj.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ0dHBwaWhza2JmbXh3dWp5enRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk2OTk2OTksImV4cCI6MjA5NTI3NTY5OX0.HVy2iOv9t4u6vA2TaMolp2GOrvi-5m9pLW1lXKCnEl8";
const EXTENSION_VERSION = "1.0.62";
const ALARM = "pd_tick";
const TICK_SECONDS = 3;
const SELF_CHAIN_MS_MIN = 200;
const SELF_CHAIN_MS_MAX = 800;
function selfChainDelay() {
  // Random jitter so the scrape cadence isn't a robot-perfect clock.
  return Math.floor(SELF_CHAIN_MS_MIN + Math.random() * (SELF_CHAIN_MS_MAX - SELF_CHAIN_MS_MIN));
}
const EMPTY_PAUSE_MS = 5000;
const BATCH_SIZE = 15;
const PARALLEL_TABS = 5;
const TAB_TIMEOUT_MS = 35000;
const HEARTBEAT_INTERVAL_MS = 5 * 60 * 1000;
const RECIPES_TTL_MS = 24 * 60 * 60 * 1000;
const RECENT_WRITE_TTL_MS = 60000;

chrome.runtime.onInstalled.addListener(setupAlarm);
chrome.runtime.onStartup.addListener(setupAlarm);
function setupAlarm() { chrome.alarms.create(ALARM, { periodInMinutes: TICK_SECONDS / 60 }); }
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) tick().catch(e => console.warn("[PD] tick err:", e)); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "pd_diag") {
    const tag = msg.source === "MANUAL" ? "[PD-DIAG-MANUAL]" : "[PD-DIAG-AUTO]";
    console.log(tag, msg.platform, "url=", msg.url?.substring(0,80),
      "price=", msg.price, "rating=", msg.rating, "count=", msg.reviewCount,
      "seller=", msg.seller, "ok=", msg.success);
    sendResponse({ok: true});
    return true;
  }
  if (msg.action === "pd_signed_in" || msg.action === "pd_start") { setupAlarm(); tick(); sendResponse({ ok: true }); return true; }
  if (msg.action === "pd_stop" || msg.action === "pd_signed_out") { chrome.alarms.clear(ALARM); sendResponse({ ok: true }); return true; }
  if (msg.action === "pd_bridge_signin") {
    (async () => {
      try {
        if (!sender.tab || !sender.tab.url || !sender.tab.url.startsWith("https://cursive.world/")) {
          sendResponse({ ok: false, error: "Invalid origin" }); return;
        }
        await chrome.storage.local.set({
          pd_jwt: msg.access_token,
          pd_refresh_token: msg.refresh_token || null,
          pd_jwt_expires_at: msg.expires_at || (Date.now() + 3600 * 1000),
          pd_email: msg.email, pd_running: true,
        });
        setupAlarm(); tick().catch(() => {});
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false, error: e.message }); }
    })();
    return true;
  }
  sendResponse({ ok: true }); return true;
});

const _recentlyWritten = new Map();
function markRecentlyWritten(productId) { _recentlyWritten.set(productId, Date.now()); }
function isRecentlyWritten(productId) {
  const t = _recentlyWritten.get(productId);
  if (!t) return false;
  if (Date.now() - t > RECENT_WRITE_TTL_MS) { _recentlyWritten.delete(productId); return false; }
  return true;
}

async function openBridgeTabForResume() { return; }

async function getAuth() {
  const s = await chrome.storage.local.get(["pd_jwt", "pd_refresh_token", "pd_jwt_expires_at", "pd_running"]);
  if (s.pd_running === false) return null;

  const hasJwt = !!s.pd_jwt;
  const expiresAt = s.pd_jwt_expires_at || 0;
  const expiresIn = expiresAt - Date.now();
  const needsRefresh = !hasJwt || !expiresAt || expiresIn < 5 * 60 * 1000;

  if (needsRefresh && s.pd_refresh_token) {
    try {
      const r = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: "POST", headers: { "Content-Type": "application/json", "apikey": SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: s.pd_refresh_token }),
      });
      const j = await r.json();
      if (r.ok && j.access_token) {
        await chrome.storage.local.set({
          pd_jwt: j.access_token, pd_refresh_token: j.refresh_token,
          pd_jwt_expires_at: Date.now() + (j.expires_in * 1000),
          pd_last_refresh: Date.now(),
        });
        console.log("[PD] JWT refreshed silently. Expires in", j.expires_in, "sec");
        return j.access_token;
      } else {
        console.warn("[PD] refresh rejected:", r.status, j.error_description || j.msg);
        // Refresh token is dead. Try the bridge-tab fallback.
        openBridgeTabForResume();
      }
    } catch (e) {
      console.warn("[PD] refresh network err:", e);
      // Network might not be ready yet (right after PC boot). Don't open
      // bridge yet — next tick will retry refresh.
    }
  }

  // If we get here: refresh wasn't possible or failed.
  if (!hasJwt) return null;
  if (expiresIn < -60 * 60 * 1000) {
    // JWT is more than 1 hour expired and we couldn't refresh — don't bother
    // sending it; Supabase will 401. Try the bridge tab to recover.
    if (s.pd_refresh_token === null || s.pd_refresh_token === undefined) {
      openBridgeTabForResume();
    }
    return null;
  }
  // JWT is still valid or only recently expired — try with it.
  return s.pd_jwt;
}
async function apiFetch(path, opts = {}) {
  const jwt = await getAuth();
  if (!jwt) throw new Error("Not signed in");
  return fetch(`${SUPABASE_URL}${path}`, {
    ...opts,
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${jwt}`, "apikey": SUPABASE_ANON_KEY, ...(opts.headers || {}) },
  });
}
async function refreshRecipesIfStale() {
  const s = await chrome.storage.local.get(["pd_recipes", "pd_recipes_at"]);
  if (s.pd_recipes && s.pd_recipes_at && (Date.now() - s.pd_recipes_at) < RECIPES_TTL_MS) return s.pd_recipes;
  try {
    const r = await fetch(`${SUPABASE_URL}/functions/v1/analytics-recipes`, { headers: { "apikey": SUPABASE_ANON_KEY } });
    const j = await r.json();
    if (j.ok && j.recipes) {
      await chrome.storage.local.set({ pd_recipes: j.recipes, pd_recipes_at: Date.now() });
      return j.recipes;
    }
  } catch (e) { console.warn("[PD] recipes:", e); }
  return s.pd_recipes || null;
}
async function sendHeartbeatIfDue() {
  const s = await chrome.storage.local.get(["pd_last_heartbeat", "pd_pending_count"]);
  if (s.pd_last_heartbeat && (Date.now() - s.pd_last_heartbeat) < HEARTBEAT_INTERVAL_MS) return;
  try {
    const r = await apiFetch("/functions/v1/analytics-heartbeat", {
      method: "POST",
      body: JSON.stringify({ extension_version: EXTENSION_VERSION, platform_os: navigator.platform || "Unknown", active_products: s.pd_pending_count || 0 }),
    });
    if (r.ok) await chrome.storage.local.set({ pd_last_heartbeat: Date.now() });
  } catch (e) { console.warn("[PD] heartbeat:", e); }
}

// Legacy shim — we don't open new windows for scraping anymore


let _tickInProgress = false;
async function tick() {
  if (_tickInProgress) return;
  const jwt = await getAuth(); if (!jwt) return;
  _tickInProgress = true;
  try {
    await refreshRecipesIfStale();
    await sendHeartbeatIfDue();
    const r = await apiFetch(`/functions/v1/analytics-next-products?limit=${BATCH_SIZE}`);
    if (!r.ok) { console.warn("[PD] next-products failed:", r.status); return; }
    const j = await r.json();
    let products = (j.products || []).filter(p => !isRecentlyWritten(p.id));
    await chrome.storage.local.set({ pd_pending_count: products.length });
    if (products.length === 0) {
      setTimeout(() => tick().catch(() => {}), EMPTY_PAUSE_MS);
      return;
    }
    await chrome.storage.local.set({ pd_last_fetch: Date.now() });
    const results = [];
    for (let i = 0; i < products.length; i += PARALLEL_TABS) {
      const chunk = products.slice(i, i + PARALLEL_TABS);
      const chunkResults = await Promise.all(chunk.map(p => extractProduct(p)));
      results.push(...chunkResults);
    }
    const validResults = results.filter(r => r != null);
    if (validResults.length > 0) {
      validResults.forEach(r => markRecentlyWritten(r.product_id_fk));
      const postR = await apiFetch("/functions/v1/analytics-snapshot", {
        method: "POST", body: JSON.stringify({ results: validResults }),
      });
      if (postR.ok) await chrome.storage.local.set({ pd_last_ok: Date.now() });
    }
    setTimeout(() => tick().catch(() => {}), selfChainDelay());
  } finally { _tickInProgress = false; }
}

// ===== OFFSCREEN DOCUMENT (v1.0.9) =====
let _offscreenReady = false;
async function ensureOffscreen() {
  if (_offscreenReady) return;
  try {
    const has = await chrome.offscreen.hasDocument?.();
    if (has) { _offscreenReady = true; return; }
  } catch {}
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['DOM_PARSER'],
      justification: 'Parse marketplace HTML in background without opening tabs',
    });
    _offscreenReady = true;
  } catch (e) {
    if (String(e).includes('Only a single offscreen document')) { _offscreenReady = true; return; }
    console.warn('[PD] offscreen create failed:', e);
    throw e;
  }
}

async function extractViaOffscreen(product) {
  await ensureOffscreen();
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(null), 15000);
    chrome.runtime.sendMessage({ action: 'pd_scrape_url', product }, (resp) => {
      clearTimeout(timer);
      if (chrome.runtime.lastError) return resolve(null);
      resolve(resp);
    });
  });
}

async function extractProduct(product) {
  // v1.0.52: ALWAYS use real Chrome tabs (like OLD Ratings). Offscreen
  // fetch only sees initial HTML which doesn't have lazy-rendered seller
  // info — so for Flipkart/Myntra it would extract price+rating from
  // JSON-LD and skip the tab method, leaving seller forever null. Skip
  // offscreen, go straight to tab, let content.js extract everything.
  return await extractViaMaskTab(product);
}



let _heroWinId = null;
let _heroTabId = null;
let _heroCreatePromise = null;

// v1.0.62: Tab-leak recovery. When chrome ignores windowId for popup type,
// scrape tabs land in the customer's main Chrome. This listener catches them
// within milliseconds and moves them back to the hero popup. The hero overlay
// covers the marketplace content during the brief leak window.
const _knownScrapeTabIds = new Set();
chrome.tabs.onCreated.addListener((tab) => {
  if (!_knownScrapeTabIds.has(tab.id)) return;
  if (_heroWinId != null && tab.windowId !== _heroWinId) {
    chrome.tabs.move(tab.id, { windowId: _heroWinId, index: -1 }).catch(e => {
      console.warn("[PD] leak-move failed:", e && e.message);
    });
  }
});

async function ensureHeroPopup() {
  // v1.0.55: ONE popup window (no URL bar, no tab bar). Hero mask is the
  // active tab. Scrape tabs open as background tabs in the same popup,
  // invisible because popups have no tab bar.
  if (_heroWinId != null) {
    try { await chrome.windows.get(_heroWinId); return _heroWinId; }
    catch { _heroWinId = null; _heroTabId = null; }
  }
  if (_heroCreatePromise) return await _heroCreatePromise;
  _heroCreatePromise = (async () => {
    const win = await chrome.windows.create({
      url: chrome.runtime.getURL("mask.html"),
      focused: false,
      type: "popup",  // v1.0.62: popup hides tab strip (windowId leak handled by onCreated listener)
      width: 1920, height: 1080, left: 0, top: 0,
    });
    _heroWinId = win.id;
    _heroTabId = (win.tabs && win.tabs[0]) ? win.tabs[0].id : null;
    // Brief delay then minimize
    await new Promise(r => setTimeout(r, 200));
    try { await chrome.windows.update(_heroWinId, { state: "minimized", focused: false }); } catch {}
    return _heroWinId;
  })();
  try { return await _heroCreatePromise; }
  finally { _heroCreatePromise = null; }
}

async function extractViaMaskTab(product) {
  // v1.0.55: Create scrape tab in the HERO popup window. If it ends up
  // elsewhere (bug we hit before), move it back. Customer never sees
  // marketplace URLs — popup has no URL bar / no tab bar.
  let tabId = null;
  try {
    const winId = await ensureHeroPopup();
    console.log("[PD-TAB-OPEN]", product.platform, product.product_url?.substring(0,80));
    const tab = await new Promise((resolve, reject) => {
      chrome.tabs.create({ url: product.product_url, active: false, windowId: winId }, (t) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        resolve(t);
      });
    });
    tabId = tab.id;
    _knownScrapeTabIds.add(tabId);
    // Double-check: if Chrome put it in the wrong window, move it back NOW
    if (tab.windowId !== winId) {
      try { await chrome.tabs.move(tabId, { windowId: winId, index: -1 }); } catch {}
    }
    // If tab somehow landed in a different window, MOVE it to the hero popup
    if (tab.windowId !== winId) {
      try { await chrome.tabs.move(tabId, { windowId: winId, index: -1 }); }
      catch (e) { console.warn("tab move failed:", e.message); }
    }
    // Make sure popup stays minimized + hero tab stays active
    try { await chrome.windows.update(winId, { state: "minimized", focused: false }); } catch {}
    if (_heroTabId) {
      try { await chrome.tabs.update(_heroTabId, { active: true }); } catch {}
    }
    await waitForTabComplete(tabId, 10000);
    console.log("[PD-TAB-LOADED]", product.platform, "tabId=", tabId);
    // Force inject content.js
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"],
      });
      console.log("[PD-TAB-INJECTED]", product.platform);
    } catch (e) { console.warn("[PD-TAB-INJECT-ERR]", product.platform, e.message); }
    // Override title once
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => { document.title = "Cursive PD Tracker"; },
      });
    } catch {}
    // v1.0.61: inject hero overlay so customer sees Cursive PD Tracker hero,
    // not the marketplace page, if they click the tab in the hero window.
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: injectHeroOverlay,
        args: [chrome.runtime.getURL("icon128.png")],
      });
    } catch (e) { console.warn("[PD] overlay inject err:", e && e.message); }
    // Platform-specific wait
    const waitMs = (product.platform === "Flipkart" || product.platform === "Myntra") ? 15000 :
                   (product.platform === "Meesho") ? 9000 :
                   7000;
    await new Promise(r => setTimeout(r, waitMs));
    const data = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), TAB_TIMEOUT_MS);
      chrome.tabs.sendMessage(tabId, { action: "extractRating" }, (response) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response);
      });
    });
    try { chrome.history.deleteUrl({ url: product.product_url }).catch(() => {}); } catch {}
    _knownScrapeTabIds.delete(tabId); chrome.tabs.remove(tabId).catch(() => {});
    if (!data || !data.success) return { product_id_fk: product.id, status: "fail_temporary" };
    return {
      product_id_fk: product.id,
      rating: data.rating ?? null,
      review_count: data.reviewCount ?? null,
      price: data.price ?? null,
      seller: data.seller ?? null,
      status: ((data.price != null) || (data.rating != null)) ? "ok" : "fail_temporary",
    };
  } catch (e) {
    if (tabId) _knownScrapeTabIds.delete(tabId); chrome.tabs.remove(tabId).catch(() => {});
    console.warn("[PD] tab extract err:", e.message);
    return { product_id_fk: product.id, status: "fail_temporary" };
  }
}

async function extractViaTab(product) {
  try {
    // v1.0.19: navigate the persistent popup tab. No new tabs created.
    const { windowId, tabId } = await getScrapePopup();
    await chrome.tabs.update(tabId, { url: product.product_url });
    try { await chrome.windows.update(windowId, { state: "minimized", focused: false }); } catch {}
    await waitForTabComplete(tabId, 10000);
    // Override title so the taskbar shows "Cursive Helper", not the marketplace
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => { document.title = "Cursive Helper"; },
      });
    } catch {}
    const recipes = (await chrome.storage.local.get("pd_recipes")).pd_recipes || {};
    const recipe = recipes[product.platform] || {};
    const data = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), TAB_TIMEOUT_MS);
      chrome.tabs.sendMessage(tabId, { action: "extractRating", recipe }, (response) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response);
      });
    });
    // Park the tab back on about:blank so any visible content is hidden
    try { await chrome.tabs.update(tabId, { url: "about:blank" }); } catch {}
    // Delete from Chrome history so no "recently viewed" notifications later
    try { chrome.history.deleteUrl({ url: product.product_url }).catch(() => {}); } catch {}
    if (!data || !data.success) return { product_id_fk: product.id, status: "fail_temporary" };
    // v1.0.40: OLD Ratings content.js does linkage internally + doesn't extract seller
    return {
      product_id_fk: product.id,
      rating: data.rating ?? null,
      review_count: data.reviewCount ?? null,
      price: data.price ?? null,
      seller: data.seller ?? null,
      status: ((data.price != null) || (data.rating != null)) ? "ok" : "fail_temporary",
    };
  } catch (e) {
    console.warn("[PD] extract failed:", e);
    return { product_id_fk: product.id, status: "fail_temporary" };
  }
}
function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(false); }, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve(true), 1500);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}
console.log("[PD] Service worker boot — version", EXTENSION_VERSION);

// v1.0.61: Runs INSIDE the marketplace tab via chrome.scripting.executeScript.
// Overlays a full-screen branded hero so the customer never sees the marketplace
// page if they click the tab. content.js still reads the real DOM underneath.
function injectHeroOverlay(iconUrl) {
  try {
    if (document.getElementById("__cursive_hero_overlay__")) return;
    const overlay = document.createElement("div");
    overlay.id = "__cursive_hero_overlay__";
    overlay.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:linear-gradient(135deg,#1f6feb 0%,#1858d6 100%);color:#fff;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;pointer-events:auto;overflow:hidden;";
    overlay.innerHTML =
      '<div style="display:flex;align-items:center;gap:14px;margin-bottom:10px;">' +
        '<div style="width:56px;height:56px;border-radius:14px;background:rgba(255,255,255,0.18);display:flex;align-items:center;justify-content:center;">' +
          '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
            '<polyline points="3 17 9 11 13 15 21 6"/><polyline points="15 6 21 6 21 12"/>' +
          '</svg>' +
        '</div>' +
        '<div style="font-size:44px;font-weight:700;letter-spacing:0.5px;">Cursive<sup style="font-size:18px;">&reg;</sup></div>' +
      '</div>' +
      '<div style="font-size:13px;font-weight:700;letter-spacing:3px;background:rgba(255,255,255,0.16);padding:6px 14px;border-radius:999px;">PD TRACKER &middot; INDIA\'S SELLER TOOLKIT</div>' +
      '<div style="margin-top:36px;display:flex;gap:10px;align-items:center;background:rgba(255,255,255,0.12);padding:10px 18px;border-radius:999px;">' +
        '<span style="width:10px;height:10px;border-radius:50%;background:#22c55e;animation:cwpulse 1.6s infinite;"></span>' +
        '<span style="font-size:14px;font-weight:600;">Service active &middot; tracking your products</span>' +
      '</div>' +
      '<div style="margin-top:32px;font-size:12px;opacity:0.78;max-width:520px;line-height:1.6;">' +
        'This window is the Cursive PD Tracker background service. ' +
        'Keep it minimized in the taskbar &mdash; the service runs automatically.' +
      '</div>' +
      '<div style="position:absolute;bottom:20px;font-size:11px;opacity:0.7;">' +
        'WhatsApp +91 96257 37475 &middot; contact@cursive.world' +
      '</div>' +
      '<style>@keyframes cwpulse {0%{box-shadow:0 0 0 0 rgba(34,197,94,0.7);}70%{box-shadow:0 0 0 12px rgba(34,197,94,0);}100%{box-shadow:0 0 0 0 rgba(34,197,94,0);}}</style>';
    document.documentElement.appendChild(overlay);
    try {
      document.querySelectorAll('link[rel*="icon"]').forEach(l => l.remove());
      const link = document.createElement("link");
      link.rel = "icon"; link.href = iconUrl;
      (document.head || document.documentElement).appendChild(link);
    } catch {}
  } catch (e) { console.warn("[PD] overlay err", e); }
}

ensureHeroPopup().catch(e => console.warn("[PD] hero popup boot err:", e));
setupAlarm();
// Force-refresh JWT on boot so PC restarts don't leave us with a stale token
getAuth().then(jwt => {
  if (jwt) { console.log("[PD] JWT ready on boot, starting tick"); tick().catch(() => {}); }
  else { console.warn("[PD] No JWT on boot — opening bridge tab for silent resume"); openBridgeTabForResume(); }
}).catch(e => console.warn("[PD] boot getAuth err:", e));
