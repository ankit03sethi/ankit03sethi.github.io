const SUPABASE_URL = "https://bttppihskbfmxwujyztj.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ0dHBwaWhza2JmbXh3dWp5enRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk2OTk2OTksImV4cCI6MjA5NTI3NTY5OX0.HVy2iOv9t4u6vA2TaMolp2GOrvi-5m9pLW1lXKCnEl8";
const EXTENSION_VERSION = "1.0.41";
const ALARM = "pd_tick";
const TICK_SECONDS = 3;
const SELF_CHAIN_MS_MIN = 200;
const SELF_CHAIN_MS_MAX = 800;
function selfChainDelay() {
  // Random jitter so the scrape cadence isn't a robot-perfect clock.
  return Math.floor(SELF_CHAIN_MS_MIN + Math.random() * (SELF_CHAIN_MS_MAX - SELF_CHAIN_MS_MIN));
}
const EMPTY_PAUSE_MS = 5000;
const BATCH_SIZE = 15;
const PARALLEL_TABS = 1;
const TAB_TIMEOUT_MS = 25000;
const HEARTBEAT_INTERVAL_MS = 5 * 60 * 1000;
const RECIPES_TTL_MS = 24 * 60 * 60 * 1000;
const RECENT_WRITE_TTL_MS = 60000;

chrome.runtime.onInstalled.addListener(setupAlarm);
chrome.runtime.onStartup.addListener(setupAlarm);
function setupAlarm() { chrome.alarms.create(ALARM, { periodInMinutes: TICK_SECONDS / 60 }); }
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) tick().catch(e => console.warn("[PD] tick err:", e)); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "pd_signed_in" || msg.action === "pd_start") { setupAlarm(); tick(); sendResponse({ ok: true }); return true; }
  if (msg.action === "pd_stop" || msg.action === "pd_signed_out") { chrome.alarms.clear(ALARM); sendResponse({ ok: true }); return true; }
  if (msg.action === "pd_bridge_signin") {
    (async () => {
      try {
        if (!sender.tab || !sender.tab.url || !sender.tab.url.startsWith("https://cursive.world/")) {
          sendResponse({ ok: false, error: "Invalid origin" }); return;
        }
        await chrome.storage.local.set({
          pd_jwt: msg.access_token,
          pd_refresh_token: msg.refresh_token || null,
          pd_jwt_expires_at: msg.expires_at || (Date.now() + 3600 * 1000),
          pd_email: msg.email, pd_running: true,
        });
        setupAlarm(); tick().catch(() => {});
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false, error: e.message }); }
    })();
    return true;
  }
  sendResponse({ ok: true }); return true;
});

const _recentlyWritten = new Map();
function markRecentlyWritten(productId) { _recentlyWritten.set(productId, Date.now()); }
function isRecentlyWritten(productId) {
  const t = _recentlyWritten.get(productId);
  if (!t) return false;
  if (Date.now() - t > RECENT_WRITE_TTL_MS) { _recentlyWritten.delete(productId); return false; }
  return true;
}

let _lastBridgeOpenAt = 0;
async function openBridgeTabForResume() {
  // v1.0.14: PERMANENTLY DISABLED. Opening a tab — even minimized — is
  // visible to customer. JWT refresh now relies on the customer visiting
  // cursive.world/pdtracker/ in any normal tab, which the pd-bridge
  // content script picks up. If JWT expires and refresh token is dead,
  // scraping silently pauses (no UI activity).
  return;
}

async function getAuth() {
  const s = await chrome.storage.local.get(["pd_jwt", "pd_refresh_token", "pd_jwt_expires_at", "pd_running"]);
  if (s.pd_running === false) return null;

  const hasJwt = !!s.pd_jwt;
  const expiresAt = s.pd_jwt_expires_at || 0;
  const expiresIn = expiresAt - Date.now();
  const needsRefresh = !hasJwt || !expiresAt || expiresIn < 5 * 60 * 1000;

  if (needsRefresh && s.pd_refresh_token) {
    try {
      const r = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: "POST", headers: { "Content-Type": "application/json", "apikey": SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: s.pd_refresh_token }),
      });
      const j = await r.json();
      if (r.ok && j.access_token) {
        await chrome.storage.local.set({
          pd_jwt: j.access_token, pd_refresh_token: j.refresh_token,
          pd_jwt_expires_at: Date.now() + (j.expires_in * 1000),
          pd_last_refresh: Date.now(),
        });
        console.log("[PD] JWT refreshed silently. Expires in", j.expires_in, "sec");
        return j.access_token;
      } else {
        console.warn("[PD] refresh rejected:", r.status, j.error_description || j.msg);
        // Refresh token is dead. Try the bridge-tab fallback.
        openBridgeTabForResume();
      }
    } catch (e) {
      console.warn("[PD] refresh network err:", e);
      // Network might not be ready yet (right after PC boot). Don't open
      // bridge yet — next tick will retry refresh.
    }
  }

  // If we get here: refresh wasn't possible or failed.
  if (!hasJwt) return null;
  if (expiresIn < -60 * 60 * 1000) {
    // JWT is more than 1 hour expired and we couldn't refresh — don't bother
    // sending it; Supabase will 401. Try the bridge tab to recover.
    if (s.pd_refresh_token === null || s.pd_refresh_token === undefined) {
      openBridgeTabForResume();
    }
    return null;
  }
  // JWT is still valid or only recently expired — try with it.
  return s.pd_jwt;
}
async function apiFetch(path, opts = {}) {
  const jwt = await getAuth();
  if (!jwt) throw new Error("Not signed in");
  return fetch(`${SUPABASE_URL}${path}`, {
    ...opts,
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${jwt}`, "apikey": SUPABASE_ANON_KEY, ...(opts.headers || {}) },
  });
}
async function refreshRecipesIfStale() {
  const s = await chrome.storage.local.get(["pd_recipes", "pd_recipes_at"]);
  if (s.pd_recipes && s.pd_recipes_at && (Date.now() - s.pd_recipes_at) < RECIPES_TTL_MS) return s.pd_recipes;
  try {
    const r = await fetch(`${SUPABASE_URL}/functions/v1/analytics-recipes`, { headers: { "apikey": SUPABASE_ANON_KEY } });
    const j = await r.json();
    if (j.ok && j.recipes) {
      await chrome.storage.local.set({ pd_recipes: j.recipes, pd_recipes_at: Date.now() });
      return j.recipes;
    }
  } catch (e) { console.warn("[PD] recipes:", e); }
  return s.pd_recipes || null;
}
async function sendHeartbeatIfDue() {
  const s = await chrome.storage.local.get(["pd_last_heartbeat", "pd_pending_count"]);
  if (s.pd_last_heartbeat && (Date.now() - s.pd_last_heartbeat) < HEARTBEAT_INTERVAL_MS) return;
  try {
    const r = await apiFetch("/functions/v1/analytics-heartbeat", {
      method: "POST",
      body: JSON.stringify({ extension_version: EXTENSION_VERSION, platform_os: navigator.platform || "Unknown", active_products: s.pd_pending_count || 0 }),
    });
    if (r.ok) await chrome.storage.local.set({ pd_last_heartbeat: Date.now() });
  } catch (e) { console.warn("[PD] heartbeat:", e); }
}
let _maskWindowId = null;
let _maskTabId = null;
let _maskCreatePromise = null;
async function ensureMaskPopup() {
  // v1.0.39: type:"normal" minimized so chrome.tabs.create with windowId works
  // reliably (popup-type windows don't accept secondary tabs cleanly).
  if (_maskWindowId != null) {
    try {
      await chrome.windows.get(_maskWindowId);
      return _maskWindowId;
    } catch {
      _maskWindowId = null;
      _maskTabId = null;
    }
  }
  if (_maskCreatePromise) return await _maskCreatePromise;
  _maskCreatePromise = (async () => {
    // v1.0.40: Force desktop dimensions so marketplaces don't serve mobile pages.
    // We create at 1920x1080 (full HD desktop) THEN minimize. The window
    // remembers its size while minimized.
    const win = await chrome.windows.create({
      url: chrome.runtime.getURL("mask.html"),
      focused: false,
      type: "normal",
      width: 1920,
      height: 1080,
      left: 0,
      top: 0,
    });
    _maskWindowId = win.id;
    _maskTabId = (win.tabs && win.tabs[0]) ? win.tabs[0].id : null;
    // Brief delay to let Chrome record the dimensions before minimizing
    await new Promise(r => setTimeout(r, 100));
    try { await chrome.windows.update(_maskWindowId, { state: "minimized", focused: false }); } catch {}
    return _maskWindowId;
  })();
  try { return await _maskCreatePromise; }
  finally { _maskCreatePromise = null; }
}
// Legacy shim — we don't open new windows for scraping anymore
async function getScrapeWindow() {
  return await ensureMaskPopup();
}

let _tickInProgress = false;
async function tick() {
  if (_tickInProgress) return;
  const jwt = await getAuth(); if (!jwt) return;
  _tickInProgress = true;
  try {
    await refreshRecipesIfStale();
    await sendHeartbeatIfDue();
    const r = await apiFetch(`/functions/v1/analytics-next-products?limit=${BATCH_SIZE}`);
    if (!r.ok) { console.warn("[PD] next-products failed:", r.status); return; }
    const j = await r.json();
    let products = (j.products || []).filter(p => !isRecentlyWritten(p.id));
    await chrome.storage.local.set({ pd_pending_count: products.length });
    if (products.length === 0) {
      setTimeout(() => tick().catch(() => {}), EMPTY_PAUSE_MS);
      return;
    }
    await chrome.storage.local.set({ pd_last_fetch: Date.now() });
    const results = [];
    for (let i = 0; i < products.length; i += PARALLEL_TABS) {
      const chunk = products.slice(i, i + PARALLEL_TABS);
      const chunkResults = await Promise.all(chunk.map(p => extractProduct(p)));
      results.push(...chunkResults);
    }
    const validResults = results.filter(r => r != null);
    if (validResults.length > 0) {
      validResults.forEach(r => markRecentlyWritten(r.product_id_fk));
      const postR = await apiFetch("/functions/v1/analytics-snapshot", {
        method: "POST", body: JSON.stringify({ results: validResults }),
      });
      if (postR.ok) await chrome.storage.local.set({ pd_last_ok: Date.now() });
    }
    setTimeout(() => tick().catch(() => {}), selfChainDelay());
  } finally { _tickInProgress = false; }
}

// ===== OFFSCREEN DOCUMENT (v1.0.9) =====
let _offscreenReady = false;
async function ensureOffscreen() {
  if (_offscreenReady) return;
  try {
    const has = await chrome.offscreen.hasDocument?.();
    if (has) { _offscreenReady = true; return; }
  } catch {}
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['DOM_PARSER'],
      justification: 'Parse marketplace HTML in background without opening tabs',
    });
    _offscreenReady = true;
  } catch (e) {
    if (String(e).includes('Only a single offscreen document')) { _offscreenReady = true; return; }
    console.warn('[PD] offscreen create failed:', e);
    throw e;
  }
}

async function extractViaOffscreen(product) {
  await ensureOffscreen();
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(null), 15000);
    chrome.runtime.sendMessage({ action: 'pd_scrape_url', product }, (resp) => {
      clearTimeout(timer);
      if (chrome.runtime.lastError) return resolve(null);
      resolve(resp);
    });
  });
}

async function extractProduct(product) {
  // v1.0.21: Hybrid. Try offscreen fetch first (silent). If no data,
  // use the MASK POPUP's own tab for tab-based scraping. Tab navigates
  // mask.html → product URL → extract → back to mask.html. Customer sees
  // only "Cursive PD Tracker" in taskbar at all times (title aggressively
  // overridden after every navigation).
  try {
    const off = await extractViaOffscreen(product);
    if (off && off.success && (off.price != null || off.rating != null)) {
      // v1.0.38: rating/count linkage — can't have one without the other
      let r = off.rating ?? null;
      let rc = off.review_count ?? null;
      if (r == null || rc == null) { r = null; rc = null; }
      return {
        product_id_fk: product.id, rating: r,
        review_count: rc, price: off.price ?? null,
        seller: off.seller ?? null, status: 'ok',
      };
    }
  } catch (e) { console.warn('[PD] offscreen err:', e); }

  // Fall back: use the mask popup's tab for tab-based extraction
  try { return await extractViaMaskTab(product); }
  catch (e) {
    console.warn('[PD] mask tab extract err:', e);
    return { product_id_fk: product.id, status: 'fail_temporary',
             rating: null, review_count: null, price: null, seller: null };
  }
}



async function extractViaMaskTab(product) {
  // v1.0.39: REAL Chrome tabs (like OLD Ratings) inside the mask window.
  // No iframe — marketplaces serve full desktop pages to real tabs.
  let tabId = null;
  try {
    const winId = await ensureMaskPopup();
    const tab = await chrome.tabs.create({ url: product.product_url, active: false, windowId: winId });
    tabId = tab.id;
    // Keep window minimized
    try { await chrome.windows.update(winId, { state: "minimized", focused: false }); } catch {}
    await waitForTabComplete(tabId, 10000);
    // Override title — taskbar / Alt-Tab show "Cursive PD Tracker" not marketplace
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          document.title = "Cursive PD Tracker";
          setInterval(() => { document.title = "Cursive PD Tracker"; }, 300);
        },
      });
    } catch {}
    // Give content.js a moment to extract (its own setTimeout loop runs at 2s/4s/6s)
    await new Promise(r => setTimeout(r, 3000));
    const data = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), TAB_TIMEOUT_MS);
      chrome.tabs.sendMessage(tabId, { action: "extractRating" }, (response) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response);
      });
    });
    // Delete URL from Chrome history (no "recently viewed" leak)
    try { chrome.history.deleteUrl({ url: product.product_url }).catch(() => {}); } catch {}
    chrome.tabs.remove(tabId).catch(() => {});
    if (!data || !data.success) return { product_id_fk: product.id, status: "fail_temporary" };
    // v1.0.38 linkage: rating + count must both be present or both null
    let _r = data.rating ?? null;
    let _rc = data.reviewCount ?? null;
    if (_r == null || _rc == null) { _r = null; _rc = null; }
    return {
      product_id_fk: product.id, rating: _r, review_count: _rc,
      price: data.price ?? null, seller: data.seller ?? null,
      status: ((data.price != null) || (_r != null)) ? "ok" : "fail_temporary",
    };
  } catch (e) {
    if (tabId) chrome.tabs.remove(tabId).catch(() => {});
    console.warn("[PD] tab extract err:", e.message);
    return { product_id_fk: product.id, status: "fail_temporary" };
  }
}

async function extractViaTab(product) {
  try {
    // v1.0.19: navigate the persistent popup tab. No new tabs created.
    const { windowId, tabId } = await getScrapePopup();
    await chrome.tabs.update(tabId, { url: product.product_url });
    try { await chrome.windows.update(windowId, { state: "minimized", focused: false }); } catch {}
    await waitForTabComplete(tabId, 10000);
    // Override title so the taskbar shows "Cursive Helper", not the marketplace
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => { document.title = "Cursive Helper"; },
      });
    } catch {}
    const recipes = (await chrome.storage.local.get("pd_recipes")).pd_recipes || {};
    const recipe = recipes[product.platform] || {};
    const data = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), TAB_TIMEOUT_MS);
      chrome.tabs.sendMessage(tabId, { action: "extractRating", recipe }, (response) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) return resolve(null);
        resolve(response);
      });
    });
    // Park the tab back on about:blank so any visible content is hidden
    try { await chrome.tabs.update(tabId, { url: "about:blank" }); } catch {}
    // Delete from Chrome history so no "recently viewed" notifications later
    try { chrome.history.deleteUrl({ url: product.product_url }).catch(() => {}); } catch {}
    if (!data || !data.success) return { product_id_fk: product.id, status: "fail_temporary" };
    // v1.0.40: OLD Ratings content.js does linkage internally + doesn't extract seller
    return {
      product_id_fk: product.id,
      rating: data.rating ?? null,
      review_count: data.reviewCount ?? null,
      price: data.price ?? null,
      seller: data.seller ?? null,
      status: ((data.price != null) || (data.rating != null)) ? "ok" : "fail_temporary",
    };
  } catch (e) {
    console.warn("[PD] extract failed:", e);
    return { product_id_fk: product.id, status: "fail_temporary" };
  }
}
function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(false); }, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve(true), 1500);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}
console.log("[PD] Service worker boot — version", EXTENSION_VERSION);
ensureMaskPopup().catch(e => console.warn("[PD] mask popup err:", e));
setupAlarm();
// Force-refresh JWT on boot so PC restarts don't leave us with a stale token
getAuth().then(jwt => {
  if (jwt) { console.log("[PD] JWT ready on boot, starting tick"); tick().catch(() => {}); }
  else { console.warn("[PD] No JWT on boot — opening bridge tab for silent resume"); openBridgeTabForResume(); }
}).catch(e => console.warn("[PD] boot getAuth err:", e));
